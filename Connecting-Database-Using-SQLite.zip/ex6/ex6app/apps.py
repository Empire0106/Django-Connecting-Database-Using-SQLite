from django.apps import AppConfig


class Ex6AppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ex6app'
